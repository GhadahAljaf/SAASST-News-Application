package com.example.newsapp;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newsapp.model.Article;
import com.example.newsapp.utility.ImageGenerator;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HorizontalArticleVH extends RecyclerView.ViewHolder {
    TextView title, LikeCount;
    ShapeableImageView image;
    ImageView like;
    ImageView dislike;
    FirebaseAuth mAuth;
    FirebaseUser mUser;
    DatabaseReference databaseReference;
    public static UserH currentUser;

    public HorizontalArticleVH(@NonNull View itemView) {
        super(itemView);
        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        title = itemView.findViewById(R.id.article_card_title);
        image = itemView.findViewById(R.id.article_card_img);
        like = itemView.findViewById(R.id.article_card_like);
        dislike = itemView.findViewById(R.id.article_card_dislike);
        LikeCount = itemView.findViewById(R.id.article_card_like_count);
    }

    // Bind data method sets the title in the list item to the corresponding title of the article, as well as its image
    public void bindData(Article article, HorizontalArticleAdapter.OnItemClickListener listener) {
        title.setText(article.title());
        image.setImageBitmap(ImageGenerator.GenerateImage(article));
        Context context = itemView.getContext();

        DatabaseReference articleRef = FirebaseDatabase.getInstance().getReference("ArticlesTitles1").child(title.getText().toString());
        DatabaseReference likesRef = articleRef.child("NumOfLikes");
        DatabaseReference likedByRef = articleRef.child("LikedBy");
        DatabaseReference dislikedByRef = articleRef.child("DislikedBy");

        // Set like count from Firebase
        likesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    long likes = dataSnapshot.getValue(Long.class);
                    LikeCount.setText(likes + " Likes");
                } else {
                    LikeCount.setText("0 Likes");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });

        dislike.setOnClickListener(v -> {
            if (MainActivity.currentUser == null) {
                Toast.makeText(context, "You need to sign in", Toast.LENGTH_SHORT).show();
            } else {
                likedByRef.child(mUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // User has already liked the article, remove the like
                            likedByRef.child(mUser.getUid()).removeValue();
                            likesRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    long currentLikes = dataSnapshot.exists() ? dataSnapshot.getValue(Long.class) : 0;
                                    likesRef.setValue(currentLikes - 1);
                                    LikeCount.setText((currentLikes - 1) + " Likes");
                                    dislike.setColorFilter(ContextCompat.getColor(context, R.color.dislike_button_color));
                                    like.setColorFilter(ContextCompat.getColor(context, R.color.default_button_color));

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    // Handle possible errors
                                }
                            });
                        } else {
                            dislike.setColorFilter(ContextCompat.getColor(context, R.color.dislike_button_color));
                            like.setColorFilter(ContextCompat.getColor(context, R.color.default_button_color));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle possible errors
                    }
                });
            }
        });

        like.setOnClickListener(v -> {
            if (MainActivity.currentUser == null) {
                Toast.makeText(context, "You need to sign in", Toast.LENGTH_SHORT).show();
            } else {
                likedByRef.child(mUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // User has already liked the article, remove the like
                            likedByRef.child(mUser.getUid()).removeValue();
                            likesRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    long currentLikes = dataSnapshot.exists() ? dataSnapshot.getValue(Long.class) : 0;
                                    likesRef.setValue(currentLikes - 1);
                                    LikeCount.setText((currentLikes - 1) + " Likes");
                                    like.setColorFilter(ContextCompat.getColor(context, R.color.default_button_color));

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    // Handle possible errors
                                }
                            });
                        } else {
                            // User has not liked the article, add the like
                            likedByRef.child(mUser.getUid()).setValue(true);
                            likesRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    long currentLikes = dataSnapshot.exists() ? dataSnapshot.getValue(Long.class) : 0;
                                    likesRef.setValue(currentLikes + 1);
                                    LikeCount.setText((currentLikes + 1) + " Likes");
                                    like.setColorFilter(ContextCompat.getColor(context, R.color.like_button_color));
                                    dislike.setColorFilter(ContextCompat.getColor(context, R.color.default_button_color));
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    // Handle possible errors
                                }
                            });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle possible errors
                    }
                });
            }
        });

        // Set the click listener to the item
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClick(article);
            }
        });
    }
}

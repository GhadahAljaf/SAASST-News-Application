package com.example.newsapp;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.newsapp.controller.ArticleController;
import com.example.newsapp.model.Article;
import com.example.newsapp.model.ArticleViewModel;
import com.example.newsapp.model.User;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.List;

public class Home extends Fragment
{
    private RecyclerView topNewsRV, recentRV;
    private static ArticleViewModel articleViewModel;
    private HorizontalArticleAdapter topArticleAdapter, recentArticleAdapter;
    public Home() {}

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        if(articleViewModel == null){
            articleViewModel = new ViewModelProvider(this).get(ArticleViewModel.class);
        }
        super.onCreate(savedInstanceState);
        if (getArguments() != null)
        {}
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        //initialize array of top articles
        topNewsRV = view.findViewById(R.id.top_news_rv);
        recentRV = view.findViewById(R.id.recent_rv);

        // Set up RecyclerView and its adapter here
        topNewsRV.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recentRV.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

        // Set up the top news RecyclerView adapter
        topArticleAdapter = new HorizontalArticleAdapter(new ArrayList<>(), clicked_article -> {
            Intent intent = new Intent(getContext(), DetailActivity.class);
            intent.putExtra("article id", clicked_article.id());
            startActivity(intent);
        });
        topNewsRV.setAdapter(topArticleAdapter);

        // Set up the recent news RecyclerView adapter
        recentArticleAdapter = new HorizontalArticleAdapter(new ArrayList<>(), clicked_article -> {
            Intent intent = new Intent(getContext(), DetailActivity.class);
            intent.putExtra("article id", clicked_article.id());
            startActivity(intent);
        });
        recentRV.setAdapter(recentArticleAdapter);

        // Observe the LiveData in the ViewModel for top news and update the adapter when data changes.
        articleViewModel.getArticlesLiveData(getContext(), false).observe(getViewLifecycleOwner(), articles -> {
            topArticleAdapter.setArticles(articles);
            topNewsRV.setAdapter(topArticleAdapter);
        });

        // Observe the LiveData in the ViewModel for recent news and update the adapter when data changes.
        articleViewModel.getArticlesLiveData(getContext(), false).observe(getViewLifecycleOwner(), articles -> {
            recentArticleAdapter.setArticles(articles);
            recentRV.setAdapter(recentArticleAdapter);
        });

        return view;
    }

}
package com.example.newsapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private CalendarView calendarView;
    private EditText editText;
    private String stringDateSelected;
    private DatabaseReference databaseReference;
    TextView forgotPassword;

    ImageView tempBtn, homeBtn, newsBtn, eventsBtn, publishBtn, aboutBtn, chatBtn;
    Button LoginPopUpBtn, LanguageBtn, logoutButton;
    int container, inactiveColor, activeColor;
    FrameLayout containerLayout;
    ArrayList<UserH> userHS;

    FirebaseUser fbUser;
    FirebaseAuth mAuth;
    public static UserH currentUser;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase Authentication
        FirebaseApp.initializeApp(this);
        mAuth = FirebaseAuth.getInstance();
        auth = FirebaseAuth.getInstance();

        // Initialize users array
        userHS = new ArrayList<UserH>();

        // Set the custom action bar layout as the action bar
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(R.layout.action_bar);
        View actionBarView = getSupportActionBar().getCustomView();

        // Set button variables to their corresponding button views
        homeBtn = findViewById(R.id.home_btn);
        newsBtn = findViewById(R.id.news_btn);
        eventsBtn = findViewById(R.id.events_btn);
        publishBtn = findViewById(R.id.publish_btn);
        aboutBtn = findViewById(R.id.about_btn);
        LoginPopUpBtn = actionBarView.findViewById(R.id.login_popup_btn);
        LanguageBtn = actionBarView.findViewById(R.id.language_switch);
        chatBtn = findViewById(R.id.chat_btn);
        logoutButton = actionBarView.findViewById(R.id.logout_popup_btn);

        // Set the inactive and active color variables
        inactiveColor = getResources().getColor(R.color.primary_dark);
        activeColor = getResources().getColor(R.color.primary_grey);

        // Set a different color to the currently open tab button
        tempBtn = homeBtn;
        tempBtn.getBackground().setTint(activeColor);

        // Set the container variable to its corresponding container view id
        container = R.id.fragment_container;
        containerLayout = findViewById(container);

        // Display the home tab by default when the app starts
        displayFragment(new Home(), "Home");

        homeBtn.setOnClickListener(view -> {
            // Switch to the home tab when the home button is pressed
            displayFragment(new Home(), "Home");

            // Change the shaded tab button
            tempBtn.getBackground().setTint(inactiveColor);
            homeBtn.getBackground().setTint(activeColor);
            tempBtn = homeBtn;
        });

        newsBtn.setOnClickListener(view -> {
            // Switch to the news tab when the news button is pressed
            displayFragment(new News(), "News");

            // Change the shaded tab button
            tempBtn.getBackground().setTint(inactiveColor);
            newsBtn.getBackground().setTint(activeColor);
            tempBtn = newsBtn;
        });

        eventsBtn.setOnClickListener(view -> {
            // Switch to the events tab when the events button is pressed
            displayFragment(new Events(), "Events");

            // Change the shaded tab button
            tempBtn.getBackground().setTint(inactiveColor);
            eventsBtn.getBackground().setTint(activeColor);
            tempBtn = eventsBtn;
        });

        chatBtn.setOnClickListener(view -> {
            // Switch to the chat tab when the chat button is pressed
            displayFragment(new ChatFragment(), "Chat");

            // Change the shaded tab button
            tempBtn.getBackground().setTint(inactiveColor);
            chatBtn.getBackground().setTint(activeColor);
            tempBtn = chatBtn;
        });

        publishBtn.setOnClickListener(view -> {
            // Switch to the publish tab when the publish button is pressed
            displayFragment(new Publish(), "Publish");

            // Change the shaded tab button
            tempBtn.getBackground().setTint(inactiveColor);
            publishBtn.getBackground().setTint(activeColor);
            tempBtn = publishBtn;
        });

        aboutBtn.setOnClickListener(view -> {
            // Switch to the about us tab when the about us button is pressed
            displayFragment(new AboutUs(), "AboutUs");

            // Change the shaded tab button
            tempBtn.getBackground().setTint(inactiveColor);
            aboutBtn.getBackground().setTint(activeColor);
            tempBtn = aboutBtn;
        });

        LoginPopUpBtn.setOnClickListener(view -> {
            // Show the login pop up
            callLoginDialog();
        });

        logoutButton.setOnClickListener(view -> {
            signOut();
        });

        LanguageBtn.setOnClickListener(view -> {
            if (LanguageBtn.getText() == getText(R.string.ar)) {
                setLocal(MainActivity.this, "ar");
                finish();
                startActivity(getIntent());
            } else if (LanguageBtn.getText() == getText(R.string.en)) {
                setLocal(MainActivity.this, "en");
                finish();
                startActivity(getIntent());
            }
        });

        getCurrentUser();
    }

    private void displayFragment(Fragment fragment, String tag) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(container, fragment, tag);
        ft.commit();

        // Handle the visibility of the chat button
        if ("Home".equals(tag)) {
            chatBtn.setVisibility(View.VISIBLE);
        } else {
            chatBtn.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Log.d("not signed in", "not signed in");
            logoutButton.setVisibility(View.GONE);
            callLoginDialog();
        } else {
            changeLoginBtn();
        }
    }

    private void callLoginDialog() {
        Dialog loginDialog;
        loginDialog = new Dialog(this);
        loginDialog.setContentView(R.layout.login_popup);

        Button loginBtn = loginDialog.findViewById(R.id.login_btn);
        Button registerBtn = loginDialog.findViewById(R.id.register_btn);

        EditText email = loginDialog.findViewById(R.id.email_et);
        EditText password = loginDialog.findViewById(R.id.password_et);
        forgotPassword = loginDialog.findViewById(R.id.forgot_password_tv);

        TextView errorTxt = loginDialog.findViewById(R.id.incorrect_message);

        loginDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        loginDialog.show();

        loginBtn.setOnClickListener(v -> {
            errorTxt.setVisibility(View.INVISIBLE);

            //Login Firebase user if the email and password text fields are not empty, and the password matches the email. Otherwise display error messages accordingly
            if (!email.getText().toString().matches("") && !password.getText().toString().matches("")) {
                String receivedEmail = email.getText().toString();
                String receivedPass = password.getText().toString();
                currentUser = new UserH(receivedEmail, receivedPass, "User", R.drawable.saasst);
                //check if the email belongs to an admin and set to admin if the condition is true
                if (currentUser.getEmail().equals("hibaeinea@gmail.com") || currentUser.getEmail().equals("madyan2435@gmail.com") || currentUser.getEmail().equals("gada.haitham@gmail.com")) {
                    currentUser.setAdmin(true);
                }
                mAuth.signInWithEmailAndPassword(receivedEmail, receivedPass)
                        .addOnCompleteListener(MainActivity.this, task -> {
                            if (task.isSuccessful()) {
                                //get an instance of the registered user
                                FirebaseUser user = mAuth.getCurrentUser();

                                //store the information of the current user in a global variable
                                currentUser.setUserName(user.getDisplayName());
                                //check if the email belongs to an admin and set to admin if the condition is true
                                if (currentUser.getEmail().equals("hibaeinea@gmail.com") || currentUser.getEmail().equals("gada.haitham@gmail.com")) {
                                    currentUser.setAdmin(true);
                                }

                                loginDialog.dismiss();

                                Toast.makeText(MainActivity.this, "Welcome " + currentUser.getUserName() + "!", Toast.LENGTH_SHORT).show();

                                changeLoginBtn();

                                //put boolean and make it true for staying logged in the shared preferences
                                SharedPreferences preferences = getPreferences(MODE_PRIVATE);
                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putBoolean("stayloggedin", true);
                                editor.apply();
                            } else {
                                // If sign in fails, display a message to the user.
                                errorTxt.setVisibility(View.VISIBLE);
                                errorTxt.setText("Login Failed");
                            }
                        });
            } else {
                errorTxt.setVisibility(View.VISIBLE);
                errorTxt.setText("Please enter Email and Password");
            }
        });

        registerBtn.setOnClickListener(v -> {
            errorTxt.setVisibility(View.INVISIBLE);
            loginDialog.dismiss();
            callRegisterDialog();
        });

        forgotPassword.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            View dialogView = getLayoutInflater().inflate(R.layout.forgot_pass_separet, null);
            EditText emailBox = dialogView.findViewById(R.id.emailBox);

            builder.setView(dialogView);
            AlertDialog dialog = builder.create();

            dialogView.findViewById(R.id.btnReset).setOnClickListener(view1 -> {
                String userEmail = emailBox.getText().toString();

                if (TextUtils.isEmpty(userEmail) || !Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()) {
                    Toast.makeText(MainActivity.this, "Enter your registered email", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.sendPasswordResetEmail(userEmail).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(MainActivity.this, "Check your email", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    } else {
                        Toast.makeText(MainActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                    }
                });
            });

            dialogView.findViewById(R.id.btnCancel).setOnClickListener(view12 -> dialog.dismiss());

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            }
            dialog.show();
        });
    }

    private void callRegisterDialog() {
        Dialog registerDialog;
        registerDialog = new Dialog(this);
        registerDialog.setContentView(R.layout.register_popup);

        Button rRegisterBtn = registerDialog.findViewById(R.id.r_register_btn);

        EditText rName = registerDialog.findViewById(R.id.r_name_et);
        EditText rEmail = registerDialog.findViewById(R.id.r_email_et);
        EditText rPassword = registerDialog.findViewById(R.id.r_password_et);

        TextView registerErrorTxt = registerDialog.findViewById(R.id.register_error_text);

        registerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        registerDialog.show();

        rRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerErrorTxt.setVisibility(View.INVISIBLE);
                String tempEmail = null;

                //Create Firebase user if the email and password text fields are not empty, otherwise display error messages accordingly
                if (!rEmail.getText().toString().matches("") && !rPassword.getText().toString().matches("")) {
                    mAuth.createUserWithEmailAndPassword(rEmail.getText().toString(), rPassword.getText().toString())
                            .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Get an instance of the registered user
                                        FirebaseUser user = mAuth.getCurrentUser();

                                        if (user != null) {
                                            // Update the display name
                                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                                    .setDisplayName(rName.getText().toString())
                                                    .build();

                                            user.updateProfile(profileUpdates).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        // Display name updated successfully
                                                        registerDialog.dismiss();
                                                        Toast.makeText(MainActivity.this, "Welcome " + user.getDisplayName() + "!", Toast.LENGTH_SHORT).show();
                                                        changeLoginBtn();
                                                    }
                                                }
                                            });
                                        }

                                        // Store the information of the current user in a global variable
                                        currentUser = new UserH(rEmail.getText().toString(), rPassword.getText().toString(), rName.getText().toString(), R.drawable.saasst);
                                        // Check if the email belongs to an admin and set to admin if the condition is true
                                        if (currentUser.getEmail().equals("hibaeinea@gmail.com") || currentUser.getEmail().equals("madyan2435@gmail.com") || currentUser.getEmail().equals("gada.haitham@gmail.com"))
                                            currentUser.setAdmin(true);

                                        //put boolean and make it true for staying logged in the shared preferences
                                        SharedPreferences preferences = getPreferences(MODE_PRIVATE);
                                        SharedPreferences.Editor editor = preferences.edit();
                                        editor.putBoolean("stayloggedin", true);
                                        editor.apply();
                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Log.w("TAG", "createUserWithEmail:failure", task.getException());
                                        registerErrorTxt.setText(task.getException().getMessage());
                                        registerErrorTxt.setVisibility(View.VISIBLE);
                                    }
                                }
                            });
                } else if (!rPassword.getText().toString().matches("")) {
                    registerErrorTxt.setText("Please enter your email");
                    registerErrorTxt.setVisibility(View.VISIBLE);
                } else if (!rEmail.getText().toString().matches("")) {
                    registerErrorTxt.setText("Please enter your password");
                    registerErrorTxt.setVisibility(View.VISIBLE);
                } else {
                    registerErrorTxt.setText("Please enter your email and password");
                    registerErrorTxt.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void signOut() {
        auth.signOut();
        Toast.makeText(MainActivity.this, "Signed out successfully!", Toast.LENGTH_SHORT).show();
        currentUser = null;
        finish();
        startActivity(getIntent());
    }

    private void updateUI(boolean isLoggedIn) {
        if (isLoggedIn) {
            FirebaseUser user = auth.getCurrentUser();
            if (user != null) {
                // Update UI with user information
                String name = user.getDisplayName();
                String email = user.getEmail();
                // Update your UI elements with the user's name and email if necessary
            }
        } else {
            // Clear UI elements or set them to default state
            changeLoginBtn();
        }
    }

    public void setLocal(Activity activity, String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);

        Resources resources = activity.getResources();

        Configuration configuration = resources.getConfiguration();
        configuration.setLocale(locale);
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());

        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", languageCode);
        editor.apply();
    }

    // Method to set the current language
    public void loadLocal() {
        SharedPreferences preferences = getSharedPreferences("Settings", MODE_PRIVATE);
        String language = preferences.getString("My_Lang", "");
        setLocal(this, language);
    }

    public void getCurrentUser() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            // Name, email address, and profile photo Url
            changeLoginBtn();
        }
    }

    public void changeLoginBtn() {
        if (currentUser != null) {
            // Ensure the currentUser is not null before accessing its methods
            LoginPopUpBtn.setBackgroundTintList(MainActivity.this.getResources().getColorStateList(R.color.primary_light));
            LoginPopUpBtn.setText(currentUser.getUserName() != null ? currentUser.getUserName() : "User");
            LoginPopUpBtn.setTextColor(getColor(R.color.dark));
            LoginPopUpBtn.setClickable(false);
            logoutButton.setVisibility(View.VISIBLE);
        } else {
            // Handle the case where currentUser is null
            LoginPopUpBtn.setBackgroundTintList(MainActivity.this.getResources().getColorStateList(R.color.primary_dark));
            LoginPopUpBtn.setText("Login");
            LoginPopUpBtn.setTextColor(getColor(R.color.dark));
            LoginPopUpBtn.setClickable(true);
            logoutButton.setVisibility(View.GONE);
        }
    }
}

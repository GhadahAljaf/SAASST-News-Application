package com.example.newsapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Events extends Fragment {

    private CalendarView calendarView;
    private EditText editText, editText2;
    private String stringDateSelected, selectedDate;
    private DatabaseReference databaseReference;
    private TextView eventsTextView;
    private ListView listView;
    private RecyclerView recyclerView;
    private List<Item> items;


    public Events() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {}

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_events, container, false);


        calendarView = rootView.findViewById(R.id.calendarView1);
        editText = rootView.findViewById(R.id.editTextText);
        //editText2 = rootView.findViewById(R.id.editTextTextMultiLine);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        selectedDate = sdf.format(new Date(calendarView.getDate())); // Get initial date

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = year + "  " + (month + 1) + "  " + dayOfMonth;
        });

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                stringDateSelected = i + "-" + (i1 + 1) + "-" + i2;
                calendarClicked();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(rootView.findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseReference = FirebaseDatabase.getInstance().getReference("Calendar");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                RecyclerView recyclerView = rootView.findViewById(R.id.recyclerView1);

                List<Item> items = new ArrayList<Item>();
                //items.add(new Item("hello", "ggg"));
                //items.add(new Item("ss", "aa"));

                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                recyclerView.setAdapter(new MyAdapter(getContext(),items));


                if (dataSnapshot.exists()) {
                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        String date = dateSnapshot.getKey();
                        String title = dateSnapshot.child("title").getValue(String.class);
                        if (title != null) {
                            // editText2.append("\n" + date + "    " + title );
                            items.add(new Item(date,title));
                        }
                    }
                } else {
                    editText2.append("\nNo data available\n");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });

        Button buttonSaveEvent = rootView.findViewById(R.id.button);
        buttonSaveEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonSaveEvent();
            }
        });

        if (MainActivity.currentUser != null && MainActivity.currentUser.isAdmin()) {
            editText.setVisibility(View.VISIBLE);
            buttonSaveEvent.setVisibility(View.VISIBLE);
        } else {
            editText.setVisibility(View.GONE);
            buttonSaveEvent.setVisibility(View.GONE);
        }

        return rootView;
    }

    private void calendarClicked() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue() != null) {
                    // Handle non-null data
                } else {
                    editText.setText("null");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    public void buttonSaveEvent() {
        databaseReference.child(stringDateSelected).child("title").setValue(editText.getText().toString());
    }
}
package com.example.newsapp;

public class Item {

    String Date;
    String Title;

    public Item(String date, String title) {
        Date = date;
        Title = title;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }
}
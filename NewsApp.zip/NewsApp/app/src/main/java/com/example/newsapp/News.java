package com.example.newsapp;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.newsapp.controller.ArticleController;
import com.example.newsapp.model.Article;
import com.example.newsapp.model.ArticleViewModel;
import com.example.newsapp.model.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class News extends Fragment
{
    RecyclerView newsListView;
    VerticalArticleAdapter newsAdapter;
    private static ArticleViewModel articleViewModel;
    public News() {}

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        if(articleViewModel == null){
            articleViewModel = new ViewModelProvider(this).get(ArticleViewModel.class);
        }
        super.onCreate(savedInstanceState);
        if (getArguments() != null)
        {}
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_news, container, false);
        newsListView = view.findViewById(R.id.news_list_view);
        newsAdapter = new VerticalArticleAdapter(new ArrayList<>(), article -> {
            Intent intent = new Intent(getContext(), DetailActivity.class);
            intent.putExtra("article id", article.id());
            startActivity(intent);
        });
        newsListView.setAdapter(newsAdapter);
        newsListView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        articleViewModel.getArticlesLiveData(getContext(), false).observe(getViewLifecycleOwner(), articles -> {
            newsAdapter.setArticles(articles);
            newsListView.setAdapter(newsAdapter);
        });
        return view;
    }
}
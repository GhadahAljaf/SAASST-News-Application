package com.example.newsapp.model;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.newsapp.controller.ArticleController;

import java.util.ArrayList;
import java.util.List;

public class ArticleViewModel extends ViewModel {
    private MutableLiveData<List<Article>> articlesLiveData;
    private ArticleController articleController;

    public LiveData<List<Article>> getArticlesLiveData(Context context, boolean getPendingArticles) {
        if (articlesLiveData == null) {
            articlesLiveData = new MutableLiveData<>();
            articleController = new ArticleController(context);
            fetchArticlesFromFirebase(getPendingArticles);
        }
        return articlesLiveData;
    }

    private void fetchArticlesFromFirebase(boolean getPendingArticles) {
        articleController.getArticles(new User("madyan2435@gmail.com", "madyan1726354"), article -> {
            List<Article> currentArticles = articlesLiveData.getValue();
            if (currentArticles == null) {
                currentArticles = new ArrayList<>();
            }
            currentArticles.add(article);
            articlesLiveData.postValue(currentArticles);
        }, getPendingArticles);
    }
}


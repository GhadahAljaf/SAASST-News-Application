package com.example.newsapp;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyHolder extends RecyclerView.ViewHolder {

    TextView date;
    TextView title;

    public MyHolder(@NonNull View itemView) {
        super(itemView);

        date = itemView.findViewById(R.id.date);
        title = itemView.findViewById(R.id.titlee);



    }
}